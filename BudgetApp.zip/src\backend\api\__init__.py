"""
Package API - Routes et schémas
"""
from src.backend.api import schemas

__all__ = ['schemas']
