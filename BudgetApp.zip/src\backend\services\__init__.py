"""
Package services - Logique métier et opérations CRUD
"""
from src.backend.services import crud

__all__ = ['crud']
